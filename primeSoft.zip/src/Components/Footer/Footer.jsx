import React from "react";
import "./Footer.css";
const Footer = () => {
  return (
    <>
      <div className="mainContainerFooter">
        <div className="topRowFooter">
          <div>
            <p className="topTxtHeader">Address</p>
            <p  className="paraTxtFooter">10025 Hemloc Ave, Fontana CA</p>
          </div>
          <div>
            <p className="topTxtHeader">Contact Us</p>
            <p className="paraTxtFooter">1+ (888) 637-7405 info@primesoftcorp.com</p>
          </div>
         
        </div>
        <div className="secondRowFooter">
        
            <p className="privacyTxt">Privacy Policy</p>
            <p className="privacyTxt1">Copyright2022</p>
            <p className="privacyTxt1"> All Rights Reserved</p>
         
         

        </div>
      </div>
    </>
  );
};

export default Footer;
