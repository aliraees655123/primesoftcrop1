import React from "react";
import ourProcessRight from './../../images/ourProcessRight.png'
import "./OurProcess.css";
const OurProcess = () => {
  return (
    <>
      <div className="mainContainerOurProcess" id="ourProcess">
        <div className="mainContainerOurProcessInner">
          <div className="leftOurProcess">
            <div>
              <div className="topOurDiv">
                <p className="ourTxtOurProcess">Our</p>
                <div className="ourProcessLine"></div>
              </div>
              <p className="ourTxtOurProcess">Process</p>
            </div>

            <div className="lineLeftInBetween"></div>

            <div className="thirdRowOurProcessLeft">
              <div className="leftCardTextNoOP">
                <div className="numberTxtOP">1</div>
                <div>
                  <p className="leftCardHeadingOP">
                    Designing the user interface of app.
                  </p>
                  <p className="leftCardTxtDetailOP">
                    {" "}
                    Lorem ipsum sit dolor amet. Mantap jiwa sangat keren sekali.
                  </p>
                </div>
              </div>
              <div className="leftCardTextNoOP">
                <div className="numberTxtOP">2</div>
                <div>
                  <p className="leftCardHeadingOP">
                    Designing the user interface of app.
                  </p>
                  <p className="leftCardTxtDetailOP">
                    {" "}
                    Lorem ipsum sit dolor amet. Mantap jiwa sangat keren sekali.
                  </p>
                </div>
              </div>
            </div>
            <div className="thirdRowOurProcessLeft">
              <div className="leftCardTextNoOP">
                <div className="numberTxtOP">3</div>
                <div>
                  <p className="leftCardHeadingOP">
                    Designing the user interface of app.
                  </p>
                  <p className="leftCardTxtDetailOP">
                    {" "}
                    Lorem ipsum sit dolor amet. Mantap jiwa sangat keren sekali.
                  </p>
                </div>
              </div>
              <div className="leftCardTextNoOP">
                <div className="numberTxtOP">4</div>
                <div>
                  <p className="leftCardHeadingOP">
                    Designing the user interface of app.
                  </p>
                  <p className="leftCardTxtDetailOP">
                    {" "}
                    Lorem ipsum sit dolor amet. Mantap jiwa sangat keren sekali.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="rightOurProcess">
            <img className="rightOurProImg" src={ourProcessRight}/>

          </div>
        </div>
      </div>
    </>
  );
};

export default OurProcess;
