import React from "react";
import "./HeaderComponent.css";
import rightMain from "./../../images/rightMain.png";
import client1 from "./../../images/client1.png";
import client2 from "./../../images/client2.png";
import client3 from "./../../images/client3.png";
import client4 from "./../../images/client4.png";
import elipsePic from "./../../images/elipse.png";
import elipsePoly from "./../../images/elipsePoly.png";

const HeaderComponent = () => {
  return (
    <>
      <div className="mainHeaderComponent">
      
        <div className="leftHeaderComp">
          <div>
            <p className="leftHP1">Turn Your Idea Into Reality</p>
            <p className="leftHP2">
              Native iOS app development partner for leading software companies.
              Skip the costly set-up of an in-house team and get straight to the
              talent.
            </p>
            <button className="btnGetQuote">Get a Quote</button>
          </div>

          <div className="topClientTxtLeft">
            <p className="joinOurClientTxt">Join Our Happy Clients:</p>
            <div className="topImagesClient">
              <img src={client1} className="clientImg" />
              <img src={client3} className="clientImg" />
              <img src={client2} className="clientImg clientImg2" />
             
              <img src={client4} className="clientImg clientImg1" />
            </div>
          </div>
        </div>
        <div className="rightHeaderComp">
          <div className="topRightForPos">
            <img src={rightMain} />
            <div className="positionCardRight">
            
              <div className="topRowPosH">
                <div className="topPosLeftHeader">
                  <div className="eclipseBack">
                    <img src={elipsePoly} />
                  </div>
                  <div className="txtPartPosLeft">
                    <p className="posNameTxt">David White</p>
                    <p className="posTimeTxt"> 3 days ago</p>
                  </div>
                </div>
                <div className="posNumberTxt">+200</div>
              </div>
              <div className="topRowPosH">
                <div className="topPosLeftHeader">
                  <div className="eclipseBack">
                    <img src={elipsePoly} />
                  </div>
                  <div className="txtPartPosLeft">
                    <p className="posNameTxt">David White</p>
                    <p className="posTimeTxt"> 3 days ago</p>
                  </div>
                </div>
                <div className="posNumberTxt">+200</div>
              </div>
              <div className="topRowPosH">
                <div className="topPosLeftHeader">
                  <div className="eclipseBack">
                    <img src={elipsePoly} />
                  </div>
                  <div className="txtPartPosLeft">
                    <p className="posNameTxt">David White</p>
                    <p className="posTimeTxt"> 3 days ago</p>
                  </div>
                </div>
                <div className="posNumberTxt">+200</div>
              </div>
              <div className="topRowPosH">
                <div className="topPosLeftHeader">
                  <div className="eclipseBack">
                    <img src={elipsePoly} />
                  </div>
                  <div className="txtPartPosLeft">
                    <p className="posNameTxt">David White</p>
                    <p className="posTimeTxt"> 3 days ago</p>
                  </div>
                </div>
                <div className="posNumberTxt">+200</div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </>
  );
};

export default HeaderComponent;
