import React, { useState, useMemo } from "react";
import "./ProjectIdea.css";
import Select from "react-select";
import countryList from "react-select-country-list";
const ProjectIdea = () => {
  const [value, setValue] = useState("");
  const options = useMemo(() => countryList().getData(), []);

  const changeHandler = (value) => {
    setValue(value);
  };
  return (
    <>
      <div className="mainContainerIdea" id="projectIdea">
        <div className="mainContainerIdeaInner">
          <p className="projIdeHeader">Have a project idea? Let’s do it</p>
          <p className="projIdeaParaTxt">
            Thank you for your interest. Fill out the form below for any
            inquiries you might have.
          </p>
          <div className="mainContainerFormPI">
            <div className="topTwoInputFormIdea">
              <div>
                <p className="txtNameForm">Your name*</p>
                <input placeholder="Enter name" className="inputFieldForm" />
              </div>
              <div>
                <p className="txtNameForm">Contact email*</p>
                <input
                  placeholder="your@example.come"
                  className="inputFieldForm"
                />
              </div>
            </div>
            <div className="topTwoInputFormIdea topTwoInputFormIdea1">
              <div>
                <p className="txtNameForm">Company name*</p>
                <input placeholder="Company name" className="inputFieldForm" />
              </div>
              <div>
                <p className="txtNameForm">Country*</p>
                <Select
                  options={options}
                  value={value}
                  className="inputFieldFormSelect"
                  onChange={changeHandler}
                />

                {/* <input placeholder="Enter name" /> */}
              </div>
            </div>
            <div className="topTextAreaField">
                <p className="yourSmsForm">Your message*</p>
                <textarea  rows="4" cols="50" placeholder="Type something here..." className="inputTextArea"></textarea>
            </div>
            <button className="sendNowBtnIdea"> 
            Send Now
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProjectIdea;
